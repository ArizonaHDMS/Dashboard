export default global.jQuery;
