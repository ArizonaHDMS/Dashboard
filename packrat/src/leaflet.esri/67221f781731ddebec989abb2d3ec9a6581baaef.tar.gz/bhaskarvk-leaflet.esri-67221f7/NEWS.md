# leaflet.esri 0.2

## Major changes

- Made the package CRAN ready

# leaflet.esri 0.1.3

## Major changes

- Support for DynamicMapLayer
- Support for ImageMapLayer

# leaflet.esri 0.1.2

## Major changes

- Support for FeatureLayer
- Support for TiledMapLayer

# leaflet.esri 0.1.0

## Major changes

- Initial Release with Esri basemap layers support
