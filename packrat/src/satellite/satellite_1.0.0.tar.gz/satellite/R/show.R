setMethod("show", signature(object = "Satellite"), 
          function(object)
          {
           print(object)
          }
)
